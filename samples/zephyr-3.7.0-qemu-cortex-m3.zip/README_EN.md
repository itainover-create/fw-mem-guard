# Verified Zephyr v3.7.0 firmware example

This package contains open-firmware build artifacts and evidence, not FW Mem Guard engine source. Use FW Mem Guard 0.3.7 or later. The tool itself is an evaluation distribution under its own license.

Configuration: Zephyr v3.7.0, commit 36940db938a8f4a1e919496793ed439850a221c2; BOARD=qemu_cortex_m3 (Arm Cortex-M3); gnuarmemb; Ubuntu 24.04 GNU Arm GCC 13.2.1. Exact tool versions, .config and CMSIS revision are included. No firmware was executed.

The source application starts with PROBE_SIZE 256 and changes to 512, rebuilt in the same directory. Final outputs were copied from build/zephyr/zephyr.map and build/zephyr/zephyr.elf into baseline.map/elf and current.map/elf. Both inventories record the actual linker outputs and hashes. zephyr_pre0.* are intermediate. zephyr_final.map is an identical alias of zephyr.map in this build; select zephyr.map with zephyr.elf.

1. Open an extracted copy as a trusted workspace. Run FW Mem Guard: Set Up / Update Project.
2. Select baseline.map + baseline.elf, then current.map + current.elf.
3. Choose FLASH and RAM. Set total/growth budgets: Flash 262144 / 0; RAM 65536 / 256 bytes.
4. Compare: PASS; Flash 8778 -> 8778; RAM 4312 -> 4568; app/libapp.a(main.c.obj) RAM +256.
5. Edit Budgets: change only RAM growth to 255. Validate and Save should show only RAM growth actual=256, limit=255; engine exit 2. Restore 256 to return PASS.

receipt.json records independent GNU objdump totals, controlled object growth, one-byte reference corruption, one-byte attribution corruption and wrong-owner rejection. The raw reports, objdump/symbol outputs, configuration and hashes are included. Verification source workflow: https://github.com/itainover-create/fw-mem-guard-031-r8-private/actions/runs/38939177609 (owner access required). Public evidence files are independently downloadable beside this ZIP.

This validates the named configuration. It does not certify all Zephyr boards, nRF Connect SDK, STM32CubeIDE or MCUXpresso.

Licenses: Zephyr and CMSIS retain Apache-2.0 and the included notices. GNU runtime components, if present, retain GPLv3 with the GCC Runtime Library Exception; corresponding notices are included. Upstream sources: https://github.com/zephyrproject-rtos/zephyr/tree/36940db938a8f4a1e919496793ed439850a221c2 and https://github.com/zephyrproject-rtos/cmsis/tree/4b96cbb174678dcd3ca86e11e1f24bc5f8726da0. The application files under source/ are supplied under the adjacent source-sample license. No upstream endorsement is implied.
