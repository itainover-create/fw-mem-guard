/* SPDX-License-Identifier: MIT */
/* Copyright (c) 2026 FW Mem Guard contributors */
#include <zephyr/kernel.h>
#define PROBE_SIZE 256
static volatile unsigned char fwmg_probe[PROBE_SIZE];
int main(void) {
    fwmg_probe[0] = 1;
    printk("FW Mem Guard probe: %u\n", fwmg_probe[PROBE_SIZE - 1]);
    return 0;
}
