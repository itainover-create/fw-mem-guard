# Try the real MicroPython F411 pair in FW Mem Guard

No board, compiler or Python installation is needed to compare these supplied files.
The ELF files are STM32 firmware inputs; do not run them on your desktop.

1. Extract this entire ZIP to a local folder.
2. Install FW Mem Guard pre-release 0.3.3 or later in VS Code and open that folder as a trusted workspace.
3. Run **FW Mem Guard: Set Up / Update Project**.
4. Select baseline/firmware.map and baseline/firmware.elf for the baseline; current/firmware.map and current/firmware.elf for the current build.
5. Select **FLASH**, the full 524,288-byte region, and **RAM**, the 114,688-byte region. FLASH_TEXT does not cover the vector table's Flash load address and should be unavailable/rejected.
6. Set Flash total budget to **524288** and growth budget to **8240**; RAM total budget to **114688** and growth budget to **4096**. Enter bytes, not KiB. These are example thresholds, not recommendations for your product.
7. Save the project when prompted. Run **FW Mem Guard: Compare Builds** if a comparison has not started.
8. Expect PASS: Flash 292212 → 300452 (+8240), RAM 22440 → 26536 (+4096). Growth exactly equals the allowed limits. RAM includes 18432 bytes of heap/stack reservations; this is not runtime peak consumption.
9. Optionally run **FW Mem Guard: Export Report for Sharing**, review the unsaved JSON tab, then choose Save As.

The built-in Run Demo uses different files and intentionally exceeds its growth budgets.

## Provenance and independent reference

The supplied artifacts identify MicroPython v1.24.1, commit ecfdd5d6f9be971852003c2049600dc7b3e2a838, NUCLEO_F411RE, arm-none-eabi-gcc 13.2.1, -Os -g3. The original README_HE.md records the build settings and change.patch records the controlled change. Firmware was not rebuilt during this review; bit-for-bit build reproduction is not claimed.

The verification folder includes raw GNU objdump 2.44 section headers from both ELFs, a section CSV independently regenerated from them, the generated profile, and comparison/same-build/reverse results from the 0.3.3 engine source and guided Map/ELF validation code. The same engine/source hashes are used by the published release. This is not an interactive VS Code or native-platform acceptance test.

You can inspect sections independently with:

    arm-none-eabi-objdump -h baseline/firmware.elf
    arm-none-eabi-objdump -h current/firmware.elf

Count allocated RAM VMA ranges, including .heap/.stack reservations. Count loadable Flash LMA ranges; .isr_vector and .data each occupy RAM at runtime and have a Flash load image. Do not count debug sections or unused region capacity. The provided expected_reference_sections.csv lists the exact entries.

## Contents and licenses

The four firmware files are unchanged from the supplied originals. They retain symbols, debug information and build paths; they are sample firmware, not privacy-reduced report exports. Original file hashes are in SHA256SUMS.txt. PACKAGE_SHA256SUMS.txt also covers the added guides, verification and license notices.

MicroPython's MIT license is included as LICENSE_MicroPython.txt. This STM32 firmware also incorporates vendor/library components with their own terms, including ST USB licensing restrictions, ARM CMSIS Apache terms, library notices and the GCC Runtime Library Exception. Keep the licenses directory with any redistribution. The ST license URL currently serves SLA0044 Rev5; its full text and original source notices are included. The package as a whole is not relicensed under MIT or the FW Mem Guard evaluation license. Upstream projects and vendors do not endorse FW Mem Guard.

FW Mem Guard engine source is not included in this example package.
